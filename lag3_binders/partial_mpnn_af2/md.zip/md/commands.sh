qsub -P chemical -q test -N mmpbsa -l select=49:ncpus=1:centos=icelake -l walltime=48:00:00 mmpbsa.sh
qsub -P chemical -q test -N gmx_m-5 -l select=1:ncpus=40:centos=icelake -l walltime=06:00:00 run_gmxmmpbsa.sh
for i in {0..49} ; do grep "binding" $i/total.dat | awk '{print $4, $6}' >> gmx_mmpbsa_be_yesie.txt ; done
for i in {0..49} ; do grep "ΔTOTAL" $i/total.dat | awk '{print $2, $3}' >> gmx_mmpbsa_be_noie.txt ; done
