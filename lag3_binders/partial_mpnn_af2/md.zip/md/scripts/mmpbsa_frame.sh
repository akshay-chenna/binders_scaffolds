# Script to perform mmpbsa synu lag3 complex
# 30-Aug-2023, IIT Delhi

cd $PBS_O_WORKDIR
module load apps/gromacs/5.1.4/intel

gmx_mpi grompp -f em1.mdp -c conf_i.gro -r conf_i.gro -p topol.top -o mmpbsa.tpr -po noout.mdp

mmpbsa() {
	for i in {1..1} # Number of serial runs on each core
		do
                export OMP_NUM_THREADS=1
		x=$1
		echo 18 19 | mpirun -np 1 -host `sed "$1q;d" $PBS_NODEFILE` ./g_mmpbsa -f md_corrected.xtc -s mmpbsa.tpr -n index.ndx -i mmpbsa.mdp -pdie 4 -mme -mm mm4_$1.xvg -pbsa -pol pol4_$1.xvg -apol apol4_$1.xvg -decomp -mmcon contrib_mm4_$1.dat -pcon contrib_pol4_$1.dat -apcon contrib_apol4_$1.dat -b $((5000+(x-1)*260)) -e $((5000+x*260)) -dt 20 
		cd .. 
	done
}

for task in {1..20} # Number of parallel runs
do
	mmpbsa $task &
done
wait
