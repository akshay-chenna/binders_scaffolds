cd $PBS_O_WORKDIR
source ~/apps/scripts/source_conda.sh
conda activate gmxMMPBSA

for i in {0..0}
do
cd $i
mpirun -np 40 gmx_MMPBSA -i mmpbsa.in -o total.dat -eo total_frame.csv -do decomp.dat -deo decomp_frame.csv -cs frame_cluster.tpr -ci index.ndx -cg 19 18 -ct md_corrected.xtc -cp topol.top -nogui
cd ..
done
