for run in {1..10}
do
cp par_run.sh par_run${run}.sh
sed -i "2iz=${run}" par_run${run}.sh
qsub -P chemical -q test -N RFDiffusion${run} -l select=1:ngpus=1:ncpus=5:centos=icelake -l walltime=05:00:00 par_run${run}.sh
done
