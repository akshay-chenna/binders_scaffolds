# As opposed to the RPM'S JCTC paper and my cyclotide work, I am using a distance of 6A for interface definition intead of 5A.

import MDAnalysis as mda
import numpy as np

major_r = np.array([36,84,126,130])
all_r = np.array([36, 37, 38, 39, 40, 41, 79, 81, 83, 84, 85, 124, 126, 130, 131, 132, 133, 134, 135, 136])
u = mda.Universe('mdframe.pdb','md_corrected.xtc')
interface = '(around 6 (chainID A and not (name H* or name [1-9]H*))) and (chainID B and not ( name H* or name [1-9]H*))'

contacts = []
for i in range(len(u.trajectory)):
        u.trajectory[i]
        contacts.append(np.unique(u.select_atoms(interface).resids-15)) # Subtracting 15 (length of synuclein)

major_frac = []
all_frac = []

for i in contacts:
        major_frac.append(len(np.intersect1d(i,major_r))/4)
        all_frac.append(len(np.intersect1d(i,all_r))/20)

np.save('arginines_contactfraction.npy',major_frac) #arginines were used to define the hotspots for rfdiffusion
np.save('nmr_contactfraction.npy',all_frac) 
