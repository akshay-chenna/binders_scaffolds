# Script to perform mmpbsa peptide lag3 complex
# 30-Aug-2023, IIT Delhi

cd $PBS_O_WORKDIR
module load apps/gromacs/5.1.4/intel

mmpbsa() {
	for i in {1..1} # Number of serial runs on each core
		do
		cd $1
                export OMP_NUM_THREADS=1
                #gmx_mpi grompp -f em1.mdp -c conf_i.gro -r conf_i.gro -p topol.top -o mmpbsa.tpr -po noout.mdp
		echo 18 19 | mpirun -np 1 -host `sed "$1q;d" $PBS_NODEFILE` ./g_mmpbsa -f md_corrected.xtc -s mmpbsa.tpr -n index.ndx -i mmpbsa16.mdp -pdie 16 -mme -mm mm16.xvg -pbsa -pol pol16.xvg -apol apol16.xvg -decomp -mmcon contrib_mm16.dat -pcon contrib_pol16.dat -apcon contrib_apol16.dat -b 5000 -e 10000 -dt 50 
		cd .. 
	done
}

for task in {1..50} # Number of parallel runs
do
	mmpbsa $task &
done
wait
