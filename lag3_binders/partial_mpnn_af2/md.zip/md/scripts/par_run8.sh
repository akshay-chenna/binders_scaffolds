cd $PBS_O_WORKDIR
z=8

for ((i=$(((z-1)*5+1)); i<=$(((z-1)*5+5)); i++))
do
		
	mkdir $i
	cp -r inputs/* ${i}/.
	cp passed_rmsds/${i}_af2-p.pdb ${i}/.	
	
	cd $i
	
	nohup bash simulation.sh &
	echo "Launched simulation $i"
       	cd ..		
done
wait
